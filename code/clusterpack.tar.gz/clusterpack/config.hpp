#ifndef CONFIG_HPP_
#define CONFIG_HPP_

#include <random>

//#define PRIMEFAC_PROGRESS

typedef std::mt19937_64 Prng;
	
#endif
