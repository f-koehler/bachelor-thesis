import os
import subprocess
import numpy as np

prog = "../../bin/onestep"
N = 11607258
Na = 500
Nc = 300
Fc = 0.997
t = [1, 2, 4, 8]
r = 100

for _t in t:
    subprocess.call([prog, "-N", str(N), "-k", "auto", "-Na", str(Na), "-Nc", str(Nc), "-Fc", str(Fc), "-t", str(_t), "-r", str(r), "-o", str(_t)+".txt"])
